import React from "react";
import Sidebar from "./Sidebar";
import Hero from "./Hero"
function HOme() {
  return (
    <div>
      <Hero/>
      <br />
      <br />
      <Sidebar/>
    </div>
  );
}

export default HOme;
